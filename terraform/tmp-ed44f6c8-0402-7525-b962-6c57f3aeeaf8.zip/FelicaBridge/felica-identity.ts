export interface felicaIdentity {
  idm: string;
}

export const isFelicaIdentity = (x: any): x is felicaIdentity =>
  x !== undefined && x !== null && "idm" in x;
