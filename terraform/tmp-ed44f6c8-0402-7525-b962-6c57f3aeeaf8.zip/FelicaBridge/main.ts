import { felicaIdentity } from "./felica-identity";
export const main = (felica: felicaIdentity) => {};
